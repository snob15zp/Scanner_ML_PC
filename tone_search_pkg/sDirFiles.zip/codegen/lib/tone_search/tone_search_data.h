/*
 * File: tone_search_data.h
 *
 * MATLAB Coder version            : 5.3
 * C/C++ source code generated on  : 10-May-2023 17:26:57
 */

#ifndef TONE_SEARCH_DATA_H
#define TONE_SEARCH_DATA_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#endif
/*
 * File trailer for tone_search_data.h
 *
 * [EOF]
 */
