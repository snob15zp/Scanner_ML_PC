/*
 * File: sind.h
 *
 * MATLAB Coder version            : 5.3
 * C/C++ source code generated on  : 10-May-2023 17:26:57
 */

#ifndef SIND_H
#define SIND_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void b_sind(double *x);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for sind.h
 *
 * [EOF]
 */
