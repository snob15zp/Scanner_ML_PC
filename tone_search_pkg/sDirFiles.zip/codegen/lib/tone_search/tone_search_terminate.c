/*
 * File: tone_search_terminate.c
 *
 * MATLAB Coder version            : 5.3
 * C/C++ source code generated on  : 10-May-2023 17:26:57
 */

/* Include Files */
#include "tone_search_terminate.h"
#include "rt_nonfinite.h"

/* Function Definitions */
/*
 * Arguments    : void
 * Return Type  : void
 */
void tone_search_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for tone_search_terminate.c
 *
 * [EOF]
 */
