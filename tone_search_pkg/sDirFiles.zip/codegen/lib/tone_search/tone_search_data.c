/*
 * File: tone_search_data.c
 *
 * MATLAB Coder version            : 5.3
 * C/C++ source code generated on  : 10-May-2023 17:26:57
 */

/* Include Files */
#include "tone_search_data.h"
#include "rt_nonfinite.h"

/*
 * File trailer for tone_search_data.c
 *
 * [EOF]
 */
