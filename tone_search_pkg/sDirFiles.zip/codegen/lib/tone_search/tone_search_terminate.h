/*
 * File: tone_search_terminate.h
 *
 * MATLAB Coder version            : 5.3
 * C/C++ source code generated on  : 10-May-2023 17:26:57
 */

#ifndef TONE_SEARCH_TERMINATE_H
#define TONE_SEARCH_TERMINATE_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void tone_search_terminate(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for tone_search_terminate.h
 *
 * [EOF]
 */
